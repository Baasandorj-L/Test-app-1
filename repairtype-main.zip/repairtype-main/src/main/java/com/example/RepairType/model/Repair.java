package com.example.RepairType.model;

import lombok.Data;

import java.util.List;

@Data
public class Repair {
    private List<Integer> treatments;
}
