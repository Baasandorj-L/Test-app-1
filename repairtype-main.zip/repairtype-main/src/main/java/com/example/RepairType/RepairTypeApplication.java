package com.example.RepairType;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepairTypeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RepairTypeApplication.class, args);
	}

}
