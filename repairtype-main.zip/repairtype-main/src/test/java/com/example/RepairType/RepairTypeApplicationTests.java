package com.example.RepairType;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepairTypeApplicationTests {

	@Test
	void contextLoads() {
	}

}
